public class Group extends Chat{
    public Group(User admin, String id, String name) {
        super(admin, id, name);
    }
}
